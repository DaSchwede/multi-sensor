#pragma once
void requestSensorRescan();
